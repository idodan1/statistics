#' @S3method print Brier
"print.Brier" <- function(x,digits=2,...){
  summary(x,digits=digits,print.it=TRUE,...)
}
