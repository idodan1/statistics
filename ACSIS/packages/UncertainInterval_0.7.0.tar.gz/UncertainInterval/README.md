# UncertainInterval
R package for three-way threshold determination of medical tests
date: 14 feb 2021
version 0.7.0.0
